/* ==========================================================================
   FITLOG - BACKUP & EXPORT/IMPORT MODULE
   JSON full data backup/restore + CSV history export.
   ========================================================================== */

class BackupService {
  // EXPORT FULL JSON BACKUP
  exportFullJSON() {
    const backupData = {
      app: 'FitLog Workout Log Book',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      exercises: db.getExercises(),
      routines: db.getRoutines(),
      history: db.getHistory(),
      settings: db.getSettings()
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    const filename = `fitlog_backup_${new Date().toISOString().slice(0,10)}.json`;
    
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", filename);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  // EXPORT CSV HISTORY FOR EXCEL / GOOGLE SHEETS
  exportHistoryCSV() {
    const history = db.getHistory();
    if (history.length === 0) {
      alert('Nenhum treino no histórico para exportar.');
      return;
    }

    let csvContent = 'Data,Hora,Treino,Exercício,Grupo Muscular,Série,Carga (kg/lb),Repetições,Observação\n';

    history.forEach(session => {
      const dateObj = new Date(session.endTime || session.startTime);
      const dateStr = dateObj.toLocaleDateString('pt-BR');
      const timeStr = dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      const routineName = `"${(session.routineName || 'Treino').replace(/"/g, '""')}"`;

      session.exerciseEntries.forEach(entry => {
        const exName = `"${(entry.exerciseName || '').replace(/"/g, '""')}"`;
        const group = `"${(entry.muscleGroup || '').replace(/"/g, '""')}"`;

        entry.sets.forEach(set => {
          if (set.reps > 0) {
            const setNum = set.setNumber;
            const weight = set.weight || 0;
            const reps = set.reps || 0;
            const note = `"${(set.note || '').replace(/"/g, '""')}"`;

            csvContent += `${dateStr},${timeStr},${routineName},${exName},${group},${setNum},${weight},${reps},${note}\n`;
          }
        });
      });
    });

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    const filename = `fitlog_historico_${new Date().toISOString().slice(0,10)}.csv`;

    downloadAnchor.href = url;
    downloadAnchor.download = filename;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    URL.revokeObjectURL(url);
  }

  // IMPORT JSON BACKUP
  importJSONFile(file, onSuccess, onError) {
    if (!file) return;
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        if (!parsed.exercises || !parsed.routines || !parsed.history) {
          throw new Error('Formato de arquivo inválido. Certifique-se de que é um arquivo de backup do FitLog.');
        }

        // Restore to DB
        localStorage.setItem(DB_KEYS.EXERCISES, JSON.stringify(parsed.exercises));
        localStorage.setItem(DB_KEYS.ROUTINES, JSON.stringify(parsed.routines));
        localStorage.setItem(DB_KEYS.HISTORY, JSON.stringify(parsed.history));
        if (parsed.settings) {
          localStorage.setItem(DB_KEYS.SETTINGS, JSON.stringify(parsed.settings));
        }

        if (onSuccess) onSuccess();
      } catch (err) {
        if (onError) onError(err.message);
      }
    };

    reader.readAsText(file);
  }
}

const backupService = new BackupService();
