/* ==========================================================================
   FITLOG - SMART OFFLINE AI WORKOUT TEXT ASSISTANT
   Parses natural language notes into structured workouts instantly.
   100% Offline, no external server or API key needed.
   ========================================================================== */

class AIWorkoutAssistant {
  parseText(inputText) {
    if (!inputText || inputText.trim().length === 0) return null;

    const lines = inputText.split(/[\n;]/).map(l => l.trim()).filter(l => l.length > 0);
    const dbExercises = db.getExercises();

    let title = 'Treino Rápido (IA)';
    const parsedExercises = [];

    lines.forEach(line => {
      // Check if line is a title e.g. "Treino de Peito", "Treino A"
      if (/^(Treino|Ficha|Rotina)\s+[A-Za-z0-9]+/i.test(line) && !line.includes('x') && !line.includes('kg')) {
        title = line.toUpperCase();
        return;
      }

      // Extract weight if present e.g. "40kg", "40 kg", "40.5kg"
      const weightMatch = line.match(/(\d+(?:[\.,]\d+)?)\s*(?:kg|lb|kilo|kilos)?/i);
      let weight = 0;

      // Extract sets x reps pattern e.g. "4x10", "3 x 12", "4 x 8-12", "4 series de 10"
      const setsRepsMatch = line.match(/(\d+)\s*(?:[xX×]|séries?|series?|sets?)\s*(?:de\s*)?(\d+)/i);
      let numSets = 3;
      let reps = 10;

      if (setsRepsMatch) {
        numSets = parseInt(setsRepsMatch[1]) || 3;
        reps = parseInt(setsRepsMatch[2]) || 10;
      }

      if (weightMatch) {
        // If weight match is different from sets/reps numbers
        const numW = parseFloat(weightMatch[1].replace(',', '.'));
        if (numW > 0 && numW !== numSets && numW !== reps) {
          weight = numW;
        }
      }

      // Clean line to find exercise name
      let cleanLine = line
        .replace(/(\d+)\s*(?:[xX×]|séries?|series?|sets?)\s*(?:de\s*)?(\d+)/gi, '')
        .replace(/(\d+(?:[\.,]\d+)?)\s*(?:kg|lb|reps?|repetições?)/gi, '')
        .replace(/^[0-9\.\-\)\s]+/, '')
        .trim();

      if (cleanLine.length >= 3) {
        // Match against database exercises
        const matchedEx = this.findBestExerciseMatch(cleanLine, dbExercises);
        
        const exName = matchedEx ? matchedEx.name : cleanLine.charAt(0).toUpperCase() + cleanLine.slice(1);
        const exId = matchedEx ? matchedEx.id : 'ex-ia-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
        const group = matchedEx ? matchedEx.muscleGroup : 'Geral';

        // Build sets array
        const sets = [];
        for (let i = 1; i <= numSets; i++) {
          sets.push({
            setNumber: i,
            weight: weight,
            reps: reps,
            completed: false
          });
        }

        parsedExercises.push({
          exerciseId: exId,
          exerciseName: exName,
          muscleGroup: group,
          sets: sets
        });
      }
    });

    if (parsedExercises.length === 0) return null;

    return {
      title: title,
      exercises: parsedExercises
    };
  }

  findBestExerciseMatch(query, exercises) {
    const q = query.toLowerCase().trim();
    
    // 1. Exact match
    let match = exercises.find(e => e.name.toLowerCase() === q);
    if (match) return match;

    // 2. Starts with / Includes match
    match = exercises.find(e => e.name.toLowerCase().includes(q) || q.includes(e.name.toLowerCase()));
    if (match) return match;

    // 3. Substring keyword match
    const words = q.split(' ').filter(w => w.length > 2);
    for (const word of words) {
      match = exercises.find(e => e.name.toLowerCase().includes(word));
      if (match) return match;
    }

    return null;
  }
}

const aiAssistant = new AIWorkoutAssistant();
