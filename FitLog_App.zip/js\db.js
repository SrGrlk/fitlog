/* ==========================================================================
   FITLOG - DATABASE LAYER (LOCALSTORAGE & INDEXEDDB ENGINE)
   100% Offline, resilient, continuous autosave, state recovery.
   ========================================================================== */

const DB_KEYS = {
  EXERCISES: 'fitlog_exercises_v1',
  ROUTINES: 'fitlog_routines_v1',
  HISTORY: 'fitlog_history_v1',
  ACTIVE_WORKOUT: 'fitlog_active_session_v1',
  SETTINGS: 'fitlog_settings_v1'
};

class LocalDatabase {
  constructor() {
    this.initDatabase();
  }

  initDatabase() {
    // 1. Seed Exercises if empty
    if (!localStorage.getItem(DB_KEYS.EXERCISES)) {
      localStorage.setItem(DB_KEYS.EXERCISES, JSON.stringify(INITIAL_EXERCISES));
    }
    // 2. Seed Routines if empty
    if (!localStorage.getItem(DB_KEYS.ROUTINES)) {
      localStorage.setItem(DB_KEYS.ROUTINES, JSON.stringify(INITIAL_ROUTINES));
    }
    // 3. Seed History if empty
    if (!localStorage.getItem(DB_KEYS.HISTORY)) {
      localStorage.setItem(DB_KEYS.HISTORY, JSON.stringify([]));
    }
    // 4. Default Settings if empty
    if (!localStorage.getItem(DB_KEYS.SETTINGS)) {
      const defaultSettings = {
        weightUnit: 'kg',
        theme: 'dark',
        restTimerDefault: 90
      };
      localStorage.setItem(DB_KEYS.SETTINGS, JSON.stringify(defaultSettings));
    }
  }

  // --- EXERCISES ---
  getExercises() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.EXERCISES)) || [];
    } catch (e) {
      console.error('Erro ao ler exercícios:', e);
      return [];
    }
  }

  getExerciseById(id) {
    const list = this.getExercises();
    return list.find(ex => ex.id === id) || null;
  }

  saveExercise(exercise) {
    const list = this.getExercises();
    const existingIndex = list.findIndex(ex => ex.id === exercise.id);
    if (existingIndex >= 0) {
      list[existingIndex] = { ...list[existingIndex], ...exercise };
    } else {
      if (!exercise.id) exercise.id = 'ex-custom-' + Date.now();
      list.push(exercise);
    }
    localStorage.setItem(DB_KEYS.EXERCISES, JSON.stringify(list));
    return exercise;
  }

  deleteExercise(id) {
    let list = this.getExercises();
    list = list.filter(ex => ex.id !== id);
    localStorage.setItem(DB_KEYS.EXERCISES, JSON.stringify(list));
  }

  // --- ROUTINES ---
  getRoutines() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.ROUTINES)) || [];
    } catch (e) {
      console.error('Erro ao ler rotinas:', e);
      return [];
    }
  }

  getRoutineById(id) {
    const list = this.getRoutines();
    return list.find(r => r.id === id) || null;
  }

  saveRoutine(routine) {
    const list = this.getRoutines();
    const existingIndex = list.findIndex(r => r.id === routine.id);
    if (existingIndex >= 0) {
      list[existingIndex] = { ...list[existingIndex], ...routine };
    } else {
      if (!routine.id) routine.id = 'routine-' + Date.now();
      routine.createdAt = new Date().toISOString();
      list.push(routine);
    }
    localStorage.setItem(DB_KEYS.ROUTINES, JSON.stringify(list));
    return routine;
  }

  duplicateRoutine(id) {
    const original = this.getRoutineById(id);
    if (!original) return null;
    const copy = {
      ...original,
      id: 'routine-' + Date.now(),
      name: `${original.name} (Cópia)`,
      createdAt: new Date().toISOString()
    };
    return this.saveRoutine(copy);
  }

  deleteRoutine(id) {
    let list = this.getRoutines();
    list = list.filter(r => r.id !== id);
    localStorage.setItem(DB_KEYS.ROUTINES, JSON.stringify(list));
  }

  // --- WORKOUT HISTORY ---
  getHistory() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.HISTORY)) || [];
    } catch (e) {
      console.error('Erro ao ler histórico:', e);
      return [];
    }
  }

  saveWorkoutToHistory(workoutSession) {
    const history = this.getHistory();
    // Re-calculate totals before saving
    let totalVolume = 0;
    let totalSetsCount = 0;
    workoutSession.exerciseEntries.forEach(entry => {
      entry.sets.forEach(set => {
        if (set.completed || set.reps > 0) {
          totalVolume += (set.weight || 0) * (set.reps || 0);
          totalSetsCount++;
        }
      });
    });
    workoutSession.totalVolume = totalVolume;
    workoutSession.totalSets = totalSetsCount;
    workoutSession.status = 'completed';

    // Insert at beginning (newest first)
    history.unshift(workoutSession);
    localStorage.setItem(DB_KEYS.HISTORY, JSON.stringify(history));

    // Clear active session upon completion
    this.clearActiveSession();
    return workoutSession;
  }

  deleteHistoryEntry(sessionId) {
    let history = this.getHistory();
    history = history.filter(s => s.id !== sessionId);
    localStorage.setItem(DB_KEYS.HISTORY, JSON.stringify(history));
  }

  // --- LAST PERFORMANCE & RECORDS FOR AN EXERCIS E ---
  getLastPerformanceForExercise(exerciseId) {
    const history = this.getHistory();
    for (const session of history) {
      const match = session.exerciseEntries.find(e => e.exerciseId === exerciseId);
      if (match && match.sets && match.sets.length > 0) {
        // Return valid sets from the most recent session
        const validSets = match.sets.filter(s => s.reps > 0);
        if (validSets.length > 0) {
          return {
            date: session.endTime || session.startTime,
            sets: validSets,
            bestSet: validSets.reduce((prev, curr) => (curr.weight > prev.weight ? curr : prev), validSets[0])
          };
        }
      }
    }
    return null;
  }

  getExerciseRecords(exerciseId) {
    const history = this.getHistory();
    let maxWeight = 0;
    let bestSet = { weight: 0, reps: 0 };
    let maxVolume = 0;
    let historyEntries = [];

    history.forEach(session => {
      const match = session.exerciseEntries.find(e => e.exerciseId === exerciseId);
      if (match && match.sets && match.sets.length > 0) {
        let sessionExVolume = 0;
        match.sets.forEach(set => {
          if (set.reps > 0) {
            const w = set.weight || 0;
            const r = set.reps || 0;
            if (w > maxWeight) maxWeight = w;
            if (w > bestSet.weight || (w === bestSet.weight && r > bestSet.reps)) {
              bestSet = { weight: w, reps: r };
            }
            sessionExVolume += w * r;
          }
        });
        if (sessionExVolume > maxVolume) maxVolume = sessionExVolume;

        historyEntries.push({
          date: session.endTime || session.startTime,
          sets: match.sets
        });
      }
    });

    // 1RM estimation: Epley formula -> Weight * (1 + Reps/30)
    const estimated1RM = bestSet.weight > 0 ? Math.round(bestSet.weight * (1 + (bestSet.reps / 30))) : 0;

    return {
      maxWeight,
      bestSet,
      maxVolume,
      estimated1RM,
      historyEntries
    };
  }

  // --- ACTIVE WORKOUT (AUTOSAVE & RECOVERY) ---
  getActiveSession() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.ACTIVE_WORKOUT)) || null;
    } catch (e) {
      return null;
    }
  }

  saveActiveSession(session) {
    localStorage.setItem(DB_KEYS.ACTIVE_WORKOUT, JSON.stringify(session));
  }

  clearActiveSession() {
    localStorage.removeItem(DB_KEYS.ACTIVE_WORKOUT);
  }

  // --- SETTINGS ---
  getSettings() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS)) || { weightUnit: 'kg', theme: 'dark', restTimerDefault: 90 };
    } catch (e) {
      return { weightUnit: 'kg', theme: 'dark', restTimerDefault: 90 };
    }
  }

  saveSettings(settings) {
    localStorage.setItem(DB_KEYS.SETTINGS, JSON.stringify(settings));
  }

  // --- DATABASE RESET ---
  resetAllData() {
    localStorage.removeItem(DB_KEYS.EXERCISES);
    localStorage.removeItem(DB_KEYS.ROUTINES);
    localStorage.removeItem(DB_KEYS.HISTORY);
    localStorage.removeItem(DB_KEYS.ACTIVE_WORKOUT);
    localStorage.removeItem(DB_KEYS.SETTINGS);
    this.initDatabase();
  }
}

const db = new LocalDatabase();
