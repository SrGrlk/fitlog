/* ==========================================================================
   FITLOG - ADVANCED CLIENT-SIDE PDF WORKOUT PARSER
   Supports complex tables, Upper/Lower rotations, ranges (5-9, 8-12),
   rest times, notes, RIR, RPE, and custom personal trainer PDFs.
   ========================================================================== */

class PDFWorkoutParser {
  async extractTextFromPDF(file) {
    if (typeof pdfjsLib === 'undefined') {
      throw new Error('Biblioteca PDF.js não encontrada. Certifique-se de estar conectado ou ter os arquivos locais.');
    }

    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(' ');
      fullText += pageText + '\n';
    }

    return fullText;
  }

  parseWorkoutText(rawText) {
    const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const routines = [];
    let currentRoutine = null;

    // Advanced routine header detector
    // Matches: "Upper 1 — Força Primária", "Lower 2 — Ênfase Posterior", "TREINO A", "FICHA 1"
    const routineHeaderRegex = /(Upper\s*\d|Lower\s*\d|Treino\s*[A-Z0-9]|Ficha\s*[A-Z0-9]|Rotina\s*[A-Z0-9])/i;

    // Pattern for exercise line in table format:
    // e.g. "1 Supino Reto com Barra Âncora de progressão... 2× 5–9 3–5 min"
    // e.g. "Crucifixo Inclinado c/ Halteres Isolação peitoral... 2x 10-15 2-3 min"

    lines.forEach(line => {
      // Check if line starts a new routine section
      if (routineHeaderRegex.test(line) && line.length < 80) {
        if (currentRoutine && currentRoutine.exercises.length > 0) {
          routines.push(currentRoutine);
        }
        currentRoutine = {
          name: line.replace(/^(Upper|Lower|Treino|Ficha|Rotina)/i, m => m.toUpperCase()),
          exercises: []
        };
        return;
      }

      // Also check standard group headings if no routine title yet
      if (!currentRoutine) {
        if (/^(PEITO|COSTAS|PERNAS|OMBROS|BÍCEPS|TRÍCEPS|MEMBROS SUPERIORES|MEMBROS INFERIORES)/i.test(line)) {
          currentRoutine = {
            name: line.toUpperCase(),
            exercises: []
          };
          return;
        }
      }

      if (!currentRoutine) {
        currentRoutine = {
          name: 'TREINO IMPORTADO DO PDF',
          exercises: []
        };
      }

      // Check if line contains an exercise definition
      // Look for series/reps tokens like "2× 5–9", "3x 8-12", "4x10", "2× 10-15"
      const seriesRepsMatch = line.match(/(\d+)\s*[xX×]\s*(\d+(?:[–-]\d+)?)/i);

      if (seriesRepsMatch) {
        const numSets = seriesRepsMatch[1];
        const repRange = seriesRepsMatch[2];
        const setsInfo = `${numSets}x (${repRange} reps)`;

        // Extract exercise name before the notes/sets
        let rawEx = line.substring(0, line.indexOf(seriesRepsMatch[0])).trim();
        // Clean leading hierarchy numbers (H1, H2, H3, 1, 2, 3)
        rawEx = rawEx.replace(/^[Hh]?\d+[\.\)\-]?\s*/, '').trim();

        // Separate name from inline observations if possible
        let exName = rawEx;
        let notes = '';

        // Known exercise keywords for clean extraction
        const knownExKeywords = [
          'Supino', 'Remada', 'Desenvolvimento', 'Puxada', 'Crucifixo', 'Rosca', 'Tríceps',
          'Hack Squat', 'Cadeira Extensora', 'Leg Press', 'Cadeira Flexora', 'Panturrilha',
          'Stiff', 'Terra Romeno', 'Agachamento', 'Barra Fixa', 'Peck Deck', 'Crossover', 'Press Arnold'
        ];

        for (const kw of knownExKeywords) {
          const kwIdx = rawEx.indexOf(kw);
          if (kwIdx >= 0) {
            // Found keyword, extract up to next sentence or punctuation
            const nameSubstring = rawEx.substring(kwIdx);
            const words = nameSubstring.split(' ');
            // Usually 3 to 6 words make the exercise title
            let titleLength = Math.min(words.length, 5);
            if (words.length > 5 && (words[4] === 'c/' || words[4] === 'com' || words[4] === 'na')) {
              titleLength = 6;
            }
            exName = words.slice(0, titleLength).join(' ');
            notes = nameSubstring.substring(exName.length).trim();
            break;
          }
        }

        if (exName.length >= 3) {
          currentRoutine.exercises.push({
            name: exName,
            setsInfo: setsInfo,
            numSets: parseInt(numSets) || 3,
            notes: notes || 'Importado via PDF'
          });
        }
      }
    });

    if (currentRoutine && currentRoutine.exercises.length > 0) {
      routines.push(currentRoutine);
    }

    return routines;
  }
}

const pdfParser = new PDFWorkoutParser();
