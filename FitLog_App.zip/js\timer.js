/* ==========================================================================
   FITLOG - REST TIMER MODULE
   Offline audio beep synthesizer + persistent UI floating countdown.
   ========================================================================== */

class RestTimer {
  constructor() {
    this.remainingSeconds = 0;
    this.totalSeconds = 0;
    this.intervalId = null;
    this.audioCtx = null;
  }

  initAudio() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  playBeep() {
    try {
      this.initAudio();
      if (!this.audioCtx) return;

      // Play 3 short beep tones
      const now = this.audioCtx.currentTime;
      [0, 0.2, 0.4].forEach(delay => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now + delay); // A5 note
        
        gain.gain.setValueAtTime(0.3, now + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.15);
        
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        
        osc.start(now + delay);
        osc.stop(now + delay + 0.15);
      });
    } catch (e) {
      console.warn('Audio feedback error:', e);
    }
  }

  start(seconds) {
    this.initAudio();
    this.stop();
    this.totalSeconds = parseInt(seconds) || 90;
    this.remainingSeconds = this.totalSeconds;
    
    this.updateUI();
    document.getElementById('floating-rest-timer')?.classList.remove('hidden');

    this.intervalId = setInterval(() => {
      this.remainingSeconds--;
      if (this.remainingSeconds <= 0) {
        this.stop();
        this.playBeep();
        // Vibrate if supported
        if ('vibrate' in navigator) {
          navigator.vibrate([200, 100, 200, 100, 400]);
        }
      } else {
        this.updateUI();
      }
    }, 1000);
  }

  addTime(extraSeconds) {
    if (this.remainingSeconds > 0) {
      this.remainingSeconds += extraSeconds;
      this.updateUI();
    }
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.remainingSeconds = 0;
    document.getElementById('floating-rest-timer')?.classList.add('hidden');
  }

  updateUI() {
    const clockEl = document.getElementById('timer-clock');
    if (!clockEl) return;
    const mins = Math.floor(this.remainingSeconds / 60);
    const secs = this.remainingSeconds % 60;
    clockEl.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
}

const restTimer = new RestTimer();
