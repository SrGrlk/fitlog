/* ==========================================================================
   FITLOG - MAIN APPLICATION CONTROLLER
   Navigation, View Rendering, Workout Engine, State & Event Bindings.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

const App = {
  currentView: 'view-home',
  activeSession: null,
  activeTimerInterval: null,

  init() {
    // PWA Install Prompt Capture
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredInstallPrompt = e;
    });

    this.bindNavigation();
    this.bindEvents();
    this.applySettings();
    this.checkActiveSession();
    this.renderCurrentView();
  },

  // ------------------------------------------------------------------------
  // NAVIGATION & THEME
  // ------------------------------------------------------------------------
  bindNavigation() {
    document.querySelectorAll('.bottom-nav .nav-item, .nav-to').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetView = btn.getAttribute('data-target');
        if (targetView) this.switchView(targetView);
      });
    });

    document.getElementById('btn-theme-toggle')?.addEventListener('click', () => {
      const settings = db.getSettings();
      const newTheme = settings.theme === 'dark' ? 'light' : 'dark';
      settings.theme = newTheme;
      db.saveSettings(settings);
      this.applySettings();
    });
  },

  applySettings() {
    const settings = db.getSettings();
    document.documentElement.setAttribute('data-theme', settings.theme || 'dark');
    
    const themeIcon = document.querySelector('.icon-theme');
    if (themeIcon) {
      themeIcon.textContent = settings.theme === 'dark' ? '🌙' : '☀️';
    }

    const unitSelect = document.getElementById('select-unit');
    if (unitSelect) unitSelect.value = settings.weightUnit || 'kg';

    const themeSelect = document.getElementById('select-theme');
    if (themeSelect) themeSelect.value = settings.theme || 'dark';

    const restSelect = document.getElementById('select-default-rest');
    if (restSelect) restSelect.value = settings.restTimerDefault || 90;
  },

  switchView(viewId) {
    document.querySelectorAll('.view-screen').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.bottom-nav .nav-item').forEach(n => n.classList.remove('active'));

    const targetEl = document.getElementById(viewId);
    if (targetEl) targetEl.classList.add('active');

    const navBtn = document.querySelector(`.bottom-nav .nav-item[data-target="${viewId}"]`);
    if (navBtn) navBtn.classList.add('active');

    this.currentView = viewId;
    this.renderCurrentView();
  },

  renderCurrentView() {
    switch (this.currentView) {
      case 'view-home':
        this.renderHome();
        break;
      case 'view-dashboard':
        this.renderDashboard();
        break;
      case 'view-active-workout':
        this.renderActiveWorkout();
        break;
      case 'view-history':
        this.renderHistory();
        break;
      case 'view-exercises':
        this.renderExerciseCatalog();
        break;
      case 'view-routines':
        this.renderRoutinesManagement();
        break;
      case 'view-settings':
        // Settings are static
        break;
    }
  },

  // ------------------------------------------------------------------------
  // ACTIVE WORKOUT SESSION RECOVERY & AUTOSAVE
  // ------------------------------------------------------------------------
  checkActiveSession() {
    const session = db.getActiveSession();
    if (session && session.status === 'in_progress') {
      this.activeSession = session;
      this.showActiveWorkoutBanner();
      this.startWorkoutTimer();
    } else {
      this.hideActiveWorkoutBanner();
    }
  },

  showActiveWorkoutBanner() {
    const banner = document.getElementById('banner-active-workout');
    if (banner && this.activeSession) {
      document.getElementById('banner-routine-name').textContent = this.activeSession.routineName;
      banner.classList.remove('hidden');
    }
  },

  hideActiveWorkoutBanner() {
    document.getElementById('banner-active-workout')?.classList.add('hidden');
  },

  startWorkoutTimer() {
    if (this.activeTimerInterval) clearInterval(this.activeTimerInterval);
    this.activeTimerInterval = setInterval(() => {
      if (!this.activeSession) return;
      const startMs = new Date(this.activeSession.startTime).getTime();
      const nowMs = Date.now();
      const elapsedSecs = Math.floor((nowMs - startMs) / 1000);
      this.activeSession.durationSeconds = elapsedSecs;

      const mins = Math.floor(elapsedSecs / 60);
      const secs = elapsedSecs % 60;
      const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

      const bannerTimer = document.getElementById('banner-elapsed-time');
      if (bannerTimer) bannerTimer.textContent = formatted;

      const activeTimer = document.getElementById('active-timer-display');
      if (activeTimer) activeTimer.textContent = formatted;
    }, 1000);
  },

  startNewWorkout(routineId) {
    const routine = db.getRoutineById(routineId);
    if (!routine) return;

    const exercises = db.getExercises();
    const routineExEntries = routine.exerciseIds.map(exId => {
      const exObj = exercises.find(e => e.id === exId) || { name: 'Exercício', muscleGroup: 'Geral' };
      const lastPerf = db.getLastPerformanceForExercise(exId);
      
      // Default 3 initial sets per exercise
      const sets = [1, 2, 3].map(num => ({
        setId: 'set-' + Date.now() + '-' + Math.random().toString(36).substring(2,5),
        setNumber: num,
        weight: lastPerf && lastPerf.sets[num-1] ? lastPerf.sets[num-1].weight : 0,
        reps: lastPerf && lastPerf.sets[num-1] ? lastPerf.sets[num-1].reps : 0,
        rir: 0,
        completed: false
      }));

      return {
        exerciseId: exId,
        exerciseName: exObj.name,
        muscleGroup: exObj.muscleGroup,
        notes: exObj.notes || '',
        sets: sets,
        lastPerf: lastPerf
      };
    });

    this.activeSession = {
      id: 'session-' + Date.now(),
      routineId: routine.id,
      routineName: routine.name,
      startTime: new Date().toISOString(),
      status: 'in_progress',
      durationSeconds: 0,
      exerciseEntries: routineExEntries
    };

    db.saveActiveSession(this.activeSession);
    this.showActiveWorkoutBanner();
    this.startWorkoutTimer();
    this.switchView('view-active-workout');
  },

  // ------------------------------------------------------------------------
  // DASHBOARD (VIEW HOME)
  // ------------------------------------------------------------------------
  renderHome() {
    const routines = db.getRoutines();
    const history = db.getHistory();
    const settings = db.getSettings();

    // Next suggested workout logic
    const titleEl = document.getElementById('next-workout-title');
    const startBtn = document.getElementById('btn-start-quick-workout');

    if (routines.length > 0) {
      let nextRoutine = routines[0];
      if (history.length > 0) {
        const lastRoutineId = history[0].routineId;
        const lastIdx = routines.findIndex(r => r.id === lastRoutineId);
        if (lastIdx >= 0 && lastIdx < routines.length - 1) {
          nextRoutine = routines[lastIdx + 1];
        }
      }
      titleEl.textContent = nextRoutine.name;
      startBtn.onclick = () => this.startNewWorkout(nextRoutine.id);
    } else {
      titleEl.textContent = 'Nenhuma rotina cadastrada';
      startBtn.onclick = () => this.switchView('view-routines');
    }

    // Stats
    const lastDateEl = document.getElementById('stat-last-date');
    const lastRoutineEl = document.getElementById('stat-last-routine');
    const monthVolEl = document.getElementById('stat-month-volume');

    if (history.length > 0) {
      const last = history[0];
      const d = new Date(last.endTime || last.startTime);
      lastDateEl.textContent = d.toLocaleDateString('pt-BR');
      lastRoutineEl.textContent = last.routineName;

      // Calculate total volume for current month
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      let monthVolume = 0;

      history.forEach(s => {
        const sDate = new Date(s.endTime || s.startTime);
        if (sDate.getMonth() === currentMonth && sDate.getFullYear() === currentYear) {
          monthVolume += (s.totalVolume || 0);
        }
      });
      monthVolEl.textContent = `${monthVolume.toLocaleString('pt-BR')} ${settings.weightUnit}`;
    } else {
      lastDateEl.textContent = 'Nenhum';
      lastRoutineEl.textContent = '—';
      monthVolEl.textContent = `0 ${settings.weightUnit}`;
    }

    // Routines list
    const routinesListContainer = document.getElementById('home-routines-list');
    routinesListContainer.innerHTML = '';

    routines.forEach(routine => {
      const card = document.createElement('div');
      card.className = 'routine-item-card';
      card.innerHTML = `
        <div class="routine-item-info">
          <strong>${routine.name}</strong>
          <p>${routine.muscleFocus || routine.exerciseIds.length + ' exercícios'}</p>
        </div>
        <button class="btn btn-sm btn-primary">INICIAR ▶</button>
      `;
      card.addEventListener('click', () => this.startNewWorkout(routine.id));
      routinesListContainer.appendChild(card);
    });
  },

  // ------------------------------------------------------------------------
  // EXECUÇÃO DO TREINO (ACTIVE WORKOUT VIEW - CRITICAL LOG BOOK UX)
  // ------------------------------------------------------------------------
  renderActiveWorkout() {
    if (!this.activeSession) {
      document.getElementById('active-exercises-container').innerHTML = `
        <div class="section-card text-center" style="padding: 32px 16px;">
          <h3>Nenhum treino em andamento</h3>
          <p class="meta-text" style="margin: 12px 0 20px;">Escolha uma rotina na tela inicial ou na aba Treinos para começar.</p>
          <button class="btn btn-primary nav-to" data-target="view-home">Ir para o Início</button>
        </div>
      `;
      this.bindNavigation();
      return;
    }

    document.getElementById('active-workout-name').textContent = this.activeSession.routineName;
    const settings = db.getSettings();

    const container = document.getElementById('active-exercises-container');
    container.innerHTML = '';

    let totalCompletedSets = 0;

    this.activeSession.exerciseEntries.forEach((entry, exIdx) => {
      const card = document.createElement('div');
      card.className = 'exercise-workout-card';

      // Header & Last performance
      let lastPerfHtml = 'Nenhum registro anterior';
      if (entry.lastPerf && entry.lastPerf.bestSet) {
        lastPerfHtml = `Último treino: <strong>${entry.lastPerf.bestSet.weight} ${settings.weightUnit} × ${entry.lastPerf.bestSet.reps} reps</strong>`;
      }

      let setsRowsHtml = '';
      entry.sets.forEach((set, setIdx) => {
        if (set.completed) totalCompletedSets++;
        setsRowsHtml += `
          <tr class="set-row ${set.completed ? 'completed-row' : ''}">
            <td class="set-num-badge">${set.setNumber}</td>
            <td>
              <div class="input-num-wrapper">
                <button class="btn-step" onclick="App.adjustSetVal(${exIdx}, ${setIdx}, 'weight', -1)">-</button>
                <input type="number" step="0.5" class="input-set-field" value="${set.weight || ''}" 
                       placeholder="0" onchange="App.updateSetVal(${exIdx}, ${setIdx}, 'weight', this.value)">
                <button class="btn-step" onclick="App.adjustSetVal(${exIdx}, ${setIdx}, 'weight', 1)">+</button>
              </div>
            </td>
            <td>
              <div class="input-num-wrapper">
                <button class="btn-step" onclick="App.adjustSetVal(${exIdx}, ${setIdx}, 'reps', -1)">-</button>
                <input type="number" class="input-set-field" value="${set.reps || ''}" 
                       placeholder="0" onchange="App.updateSetVal(${exIdx}, ${setIdx}, 'reps', this.value)">
                <button class="btn-step" onclick="App.adjustSetVal(${exIdx}, ${setIdx}, 'reps', 1)">+</button>
              </div>
            </td>
            <td>
              <button class="btn-check-set ${set.completed ? 'checked' : ''}" 
                      onclick="App.toggleSetCheck(${exIdx}, ${setIdx})">
                ${set.completed ? '✓' : '○'}
              </button>
            </td>
          </tr>
        `;
      });

      card.innerHTML = `
        <div class="ex-card-header">
          <div>
            <h3 class="ex-card-title">${entry.exerciseName}</h3>
            <span class="ex-muscle-badge">${entry.muscleGroup}</span>
          </div>
          <button class="btn-icon" title="Ver Histórico do Exercício" onclick="App.openExerciseDetailModal('${entry.exerciseId}')">📊</button>
        </div>

        <div class="ex-last-perf-box">
          <span>${lastPerfHtml}</span>
        </div>

        <table class="sets-table">
          <thead>
            <tr>
              <th>SÉRIE</th>
              <th>CARGA (${settings.weightUnit})</th>
              <th>REPS</th>
              <th>STATUS</th>
            </tr>
          </thead>
          <tbody>
            ${setsRowsHtml}
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
          <button class="btn btn-xs btn-outline" onclick="App.addSetToExercise(${exIdx})">+ ADICIONAR SÉRIE</button>
          ${entry.sets.length > 1 ? `<button class="btn btn-xs btn-ghost-danger" onclick="App.removeSetFromExercise(${exIdx})">Remover Série</button>` : ''}
        </div>
      `;

      container.appendChild(card);
    });

    document.getElementById('active-total-sets').textContent = totalCompletedSets;
  },

  updateSetVal(exIdx, setIdx, field, val) {
    if (!this.activeSession) return;
    const num = parseFloat(val) || 0;
    this.activeSession.exerciseEntries[exIdx].sets[setIdx][field] = num;
    db.saveActiveSession(this.activeSession);
  },

  adjustSetVal(exIdx, setIdx, field, delta) {
    if (!this.activeSession) return;
    const current = this.activeSession.exerciseEntries[exIdx].sets[setIdx][field] || 0;
    const newVal = Math.max(0, current + delta);
    this.activeSession.exerciseEntries[exIdx].sets[setIdx][field] = newVal;
    db.saveActiveSession(this.activeSession);
    this.renderActiveWorkout();
  },

  toggleSetCheck(exIdx, setIdx) {
    if (!this.activeSession) return;
    const set = this.activeSession.exerciseEntries[exIdx].sets[setIdx];
    set.completed = !set.completed;
    
    db.saveActiveSession(this.activeSession);
    this.renderActiveWorkout();

    // Trigger Rest Timer when completing a set
    if (set.completed) {
      const settings = db.getSettings();
      restTimer.start(settings.restTimerDefault || 90);
    }
  },

  addSetToExercise(exIdx) {
    if (!this.activeSession) return;
    const sets = this.activeSession.exerciseEntries[exIdx].sets;
    const lastSet = sets[sets.length - 1];
    sets.push({
      setId: 'set-' + Date.now() + '-' + Math.random().toString(36).substring(2,5),
      setNumber: sets.length + 1,
      weight: lastSet ? lastSet.weight : 0,
      reps: lastSet ? lastSet.reps : 0,
      rir: lastSet ? lastSet.rir : 0,
      completed: false
    });
    db.saveActiveSession(this.activeSession);
    this.renderActiveWorkout();
  },

  removeSetFromExercise(exIdx) {
    if (!this.activeSession) return;
    const sets = this.activeSession.exerciseEntries[exIdx].sets;
    if (sets.length > 1) {
      sets.pop();
      db.saveActiveSession(this.activeSession);
      this.renderActiveWorkout();
    }
  },

  applyRepeatLastWorkout() {
    if (!this.activeSession) return;
    this.activeSession.exerciseEntries.forEach(entry => {
      if (entry.lastPerf && entry.lastPerf.sets) {
        entry.sets = entry.lastPerf.sets.map((s, i) => ({
          setId: 'set-' + Date.now() + '-' + i,
          setNumber: i + 1,
          weight: s.weight || 0,
          reps: s.reps || 0,
          rir: s.rir || 0,
          completed: false
        }));
      }
    });
    db.saveActiveSession(this.activeSession);
    this.renderActiveWorkout();
  },

  finishWorkout() {
    if (!this.activeSession) return;
    this.activeSession.endTime = new Date().toISOString();
    
    const settings = db.getSettings();
    const savedSession = db.saveWorkoutToHistory(this.activeSession);

    // Show summary modal
    document.getElementById('summary-routine-name').textContent = savedSession.routineName;
    document.getElementById('summary-duration').textContent = `${Math.round(savedSession.durationSeconds / 60)} min`;
    document.getElementById('summary-exercises-count').textContent = savedSession.exerciseEntries.length;
    document.getElementById('summary-sets-count').textContent = savedSession.totalSets;
    document.getElementById('summary-total-volume').textContent = `${savedSession.totalVolume.toLocaleString('pt-BR')} ${settings.weightUnit}`;

    document.getElementById('modal-workout-summary').classList.remove('hidden');

    this.activeSession = null;
    this.hideActiveWorkoutBanner();
    if (this.activeTimerInterval) clearInterval(this.activeTimerInterval);
  },

  // ------------------------------------------------------------------------
  // DASHBOARD DE EVOLUÇÃO & PROGRESSÃO INTERATIVA
  // ------------------------------------------------------------------------
  renderDashboard() {
    const exercises = db.getExercises();
    const settings = db.getSettings();
    const selectEl = document.getElementById('select-dashboard-exercise');

    selectEl.innerHTML = '';
    exercises.forEach(ex => {
      const opt = document.createElement('option');
      opt.value = ex.id;
      opt.textContent = `${ex.name} (${ex.muscleGroup})`;
      selectEl.appendChild(opt);
    });

    if (exercises.length > 0) {
      if (!this.selectedDashExId) this.selectedDashExId = exercises[0].id;
      selectEl.value = this.selectedDashExId;
      this.updateDashboardCharts(this.selectedDashExId);
    }

    selectEl.onchange = (e) => {
      this.selectedDashExId = e.target.value;
      this.updateDashboardCharts(this.selectedDashExId);
    };

    this.renderMuscleVolumeBars();
  },

  updateDashboardCharts(exerciseId) {
    const ex = db.getExerciseById(exerciseId);
    if (!ex) return;

    const records = db.getExerciseRecords(exerciseId);
    const settings = db.getSettings();

    document.getElementById('dash-ex-name').textContent = ex.name;
    document.getElementById('dash-stat-max-weight').textContent = `${records.maxWeight} ${settings.weightUnit}`;
    document.getElementById('dash-stat-1rm').textContent = `${records.estimated1RM} ${settings.weightUnit}`;
    document.getElementById('dash-ex-pr-badge').textContent = `${records.maxWeight} ${settings.weightUnit} PR`;

    const trendEl = document.getElementById('dash-ex-trend');
    const dateRangeEl = document.getElementById('dash-ex-date-range');

    const historyPoints = records.historyEntries.map(e => {
      const maxW = e.sets.reduce((m, s) => Math.max(m, s.weight || 0), 0);
      return {
        date: new Date(e.date),
        weight: maxW
      };
    }).reverse(); // Chronological order

    if (historyPoints.length >= 2) {
      const firstW = historyPoints[0].weight;
      const lastW = historyPoints[historyPoints.length - 1].weight;
      const diff = lastW - firstW;
      if (diff > 0) {
        trendEl.textContent = `↑ +${diff} ${settings.weightUnit} de Evolução`;
        trendEl.style.color = 'var(--color-accent)';
      } else if (diff < 0) {
        trendEl.textContent = `↓ ${diff} ${settings.weightUnit}`;
        trendEl.style.color = 'var(--color-danger)';
      } else {
        trendEl.textContent = `= Carga Mantida (${lastW} ${settings.weightUnit})`;
        trendEl.style.color = 'var(--color-primary)';
      }

      const d1 = historyPoints[0].date.toLocaleDateString('pt-BR');
      const d2 = historyPoints[historyPoints.length - 1].date.toLocaleDateString('pt-BR');
      dateRangeEl.textContent = `${d1} até ${d2}`;
    } else {
      trendEl.textContent = 'Aguardando histórico para tendência';
      trendEl.style.color = 'var(--text-muted)';
      dateRangeEl.textContent = historyPoints.length === 1 ? historyPoints[0].date.toLocaleDateString('pt-BR') : 'Nenhum registro';
    }

    this.drawSVGChart('progression-chart-svg', historyPoints);
  },

  drawSVGChart(svgId, points) {
    const svg = document.getElementById(svgId);
    if (!svg) return;
    svg.innerHTML = '';

    if (points.length === 0) {
      svg.innerHTML = `
        <text x="250" y="105" text-anchor="middle" fill="#8E8E93" font-size="14" font-family="sans-serif">
          Nenhum treino registrado para este exercício ainda
        </text>
      `;
      return;
    }

    if (points.length === 1) {
      const pt = points[0];
      svg.innerHTML = `
        <circle cx="250" cy="100" r="10" fill="#CCFF00" />
        <text x="250" y="70" text-anchor="middle" fill="#FFF" font-size="16" font-family="monospace" font-weight="bold">${pt.weight} kg</text>
        <text x="250" y="140" text-anchor="middle" fill="#8E8E93" font-size="12" font-family="sans-serif">${pt.date.toLocaleDateString('pt-BR')}</text>
      `;
      return;
    }

    const weights = points.map(p => p.weight);
    const minW = Math.min(...weights) * 0.8;
    const maxW = Math.max(...weights) * 1.2 || 10;

    const width = 500;
    const height = 200;
    const paddingX = 40;
    const paddingY = 30;

    const coords = points.map((p, i) => {
      const x = paddingX + (i / (points.length - 1)) * (width - 2 * paddingX);
      const normalizedY = (p.weight - minW) / (maxW - minW || 1);
      const y = height - paddingY - (normalizedY * (height - 2 * paddingY));
      return { x, y, weight: p.weight, date: p.date };
    });

    // Draw grid lines
    let gridHtml = '';
    [0.2, 0.5, 0.8].forEach(ratio => {
      const gY = height - paddingY - (ratio * (height - 2 * paddingY));
      gridHtml += `<line x1="${paddingX}" y1="${gY}" x2="${width - paddingX}" y2="${gY}" stroke="#33333D" stroke-dasharray="4" />`;
    });

    // Draw trend line
    const pointsString = coords.map(c => `${c.x},${c.y}`).join(' ');
    const polylineHtml = `<polyline points="${pointsString}" fill="none" stroke="#CCFF00" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />`;

    // Draw data points & labels
    let circlesHtml = '';
    coords.forEach(c => {
      circlesHtml += `
        <circle cx="${c.x}" cy="${c.y}" r="6" fill="#00E5FF" stroke="#121214" stroke-width="2" />
        <text x="${c.x}" y="${c.y - 12}" text-anchor="middle" fill="#FFFFFF" font-size="11" font-weight="bold" font-family="monospace">${c.weight}k</text>
      `;
    });

    svg.innerHTML = gridHtml + polylineHtml + circlesHtml;
  },

  renderMuscleVolumeBars() {
    const history = db.getHistory();
    const container = document.getElementById('muscle-volume-bars');
    container.innerHTML = '';

    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const muscleSetsMap = {
      'Peito': 0, 'Costas': 0, 'Pernas': 0, 'Ombros': 0, 'Bíceps': 0, 'Tríceps': 0, 'Panturrilha': 0, 'Abdômen': 0
    };

    history.forEach(session => {
      const d = new Date(session.endTime || session.startTime);
      if (d.getMonth() === currentMonth && d.getFullYear() === currentYear) {
        session.exerciseEntries.forEach(entry => {
          const group = entry.muscleGroup || 'Outros';
          const validSetsCount = entry.sets.filter(s => s.reps > 0).length;
          if (muscleSetsMap[group] !== undefined) {
            muscleSetsMap[group] += validSetsCount;
          } else {
            muscleSetsMap[group] = validSetsCount;
          }
        });
      }
    });

    const maxSets = Math.max(...Object.values(muscleSetsMap), 1);

    Object.keys(muscleSetsMap).forEach(group => {
      const count = muscleSetsMap[group];
      const pct = Math.round((count / maxSets) * 100);

      const item = document.createElement('div');
      item.className = 'volume-bar-item';
      item.innerHTML = `
        <div class="volume-bar-info">
          <span>${group}</span>
          <span class="mono">${count} séries</span>
        </div>
        <div class="volume-bar-track">
          <div class="volume-bar-fill" style="width: ${pct}%;"></div>
        </div>
      `;
      container.appendChild(item);
    });
  },
  renderHistory() {
    const history = db.getHistory();
    const settings = db.getSettings();
    const listContainer = document.getElementById('history-items-list');
    listContainer.innerHTML = '';

    if (history.length === 0) {
      listContainer.innerHTML = `
        <div class="section-card text-center" style="padding: 32px 16px;">
          <h3>Nenhum treino registrado</h3>
          <p class="meta-text">Seus treinos finalizados aparecerão aqui.</p>
        </div>
      `;
      return;
    }

    history.forEach(session => {
      const d = new Date(session.endTime || session.startTime);
      const card = document.createElement('div');
      card.className = 'history-card';

      let exSummaryHtml = '';
      session.exerciseEntries.forEach(entry => {
        const completedSets = entry.sets.filter(s => s.reps > 0);
        if (completedSets.length > 0) {
          const setsFormatted = completedSets.map(s => `${s.weight}×${s.reps}`).join(', ');
          exSummaryHtml += `
            <div class="history-ex-row">
              <strong>${entry.exerciseName}</strong>
              <span class="mono">${setsFormatted}</span>
            </div>
          `;
        }
      });

      card.innerHTML = `
        <div class="history-card-header">
          <div>
            <span class="history-date">${d.toLocaleDateString('pt-BR')} • ${d.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'})}</span>
            <h3 class="history-routine-title">${session.routineName}</h3>
          </div>
          <button class="btn-icon" title="Excluir Registro" onclick="App.deleteHistory('${session.id}')">🗑️</button>
        </div>

        <div class="history-summary-line">
          <span>${session.exerciseEntries.length} exercícios</span> • 
          <span>${session.totalSets} séries</span> • 
          <strong class="mono">${session.totalVolume.toLocaleString('pt-BR')} ${settings.weightUnit}</strong>
        </div>

        <div class="history-ex-list">
          ${exSummaryHtml}
        </div>
      `;

      listContainer.appendChild(card);
    });

    this.renderCalendarGrid();
  },

  deleteHistory(sessionId) {
    if (confirm('Tem certeza que deseja excluir este registro de treino do histórico?')) {
      db.deleteHistoryEntry(sessionId);
      this.renderHistory();
    }
  },

  renderCalendarGrid() {
    const grid = document.getElementById('calendar-days-grid');
    grid.innerHTML = '';
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const firstDayIndex = new Date(now.getFullYear(), now.getMonth(), 1).getDay();

    const history = db.getHistory();
    const workoutDays = new Set();
    history.forEach(s => {
      const d = new Date(s.endTime || s.startTime);
      if (d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()) {
        workoutDays.add(d.getDate());
      }
    });

    // Blank cells
    for (let i = 0; i < firstDayIndex; i++) {
      const blank = document.createElement('div');
      blank.className = 'cal-day-cell blank';
      grid.appendChild(blank);
    }

    // Days
    for (let day = 1; day <= daysInMonth; day++) {
      const cell = document.createElement('div');
      const hasWorkout = workoutDays.has(day);
      cell.className = `cal-day-cell ${hasWorkout ? 'has-workout' : ''}`;
      cell.innerHTML = `
        <span>${day}</span>
        ${hasWorkout ? '<span class="cal-workout-check">✓</span>' : ''}
      `;
      grid.appendChild(cell);
    }
  },

  // ------------------------------------------------------------------------
  // EXERCISE CATALOG & DETAILED MODAL
  // ------------------------------------------------------------------------
  renderExerciseCatalog(filterGroup = 'ALL', searchQuery = '') {
    let exercises = db.getExercises();
    
    if (filterGroup !== 'ALL') {
      exercises = exercises.filter(e => e.muscleGroup === filterGroup);
    }
    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase();
      exercises = exercises.filter(e => e.name.toLowerCase().includes(q) || e.muscleGroup.toLowerCase().includes(q));
    }

    const container = document.getElementById('exercise-catalog-list');
    container.innerHTML = '';

    exercises.forEach(ex => {
      const card = document.createElement('div');
      card.className = 'exercise-item-card';
      card.innerHTML = `
        <div>
          <div class="ex-title-row">
            <strong>${ex.name}</strong>
          </div>
          <span class="ex-group-tag">${ex.muscleGroup}</span>
        </div>
        <button class="btn btn-sm btn-outline">Evolução 📊</button>
      `;
      card.addEventListener('click', () => this.openExerciseDetailModal(ex.id));
      container.appendChild(card);
    });
  },

  openExerciseDetailModal(exerciseId) {
    const ex = db.getExerciseById(exerciseId);
    if (!ex) return;
    const records = db.getExerciseRecords(exerciseId);
    const settings = db.getSettings();

    document.getElementById('modal-ex-title').textContent = ex.name;
    document.getElementById('modal-ex-notes').textContent = ex.notes ? `Técnica: "${ex.notes}"` : '';

    document.getElementById('modal-ex-max-weight').textContent = `${records.maxWeight} ${settings.weightUnit}`;
    document.getElementById('modal-ex-best-set').textContent = `${records.bestSet.weight} ${settings.weightUnit} × ${records.bestSet.reps}`;
    document.getElementById('modal-ex-1rm').textContent = `${records.estimated1RM} ${settings.weightUnit}`;

    const historyListContainer = document.getElementById('modal-ex-history-list');
    historyListContainer.innerHTML = '';

    if (records.historyEntries.length === 0) {
      historyListContainer.innerHTML = '<p class="meta-text">Nenhum treino registrado para este exercício ainda.</p>';
    } else {
      records.historyEntries.forEach(entry => {
        const d = new Date(entry.date);
        const setsStr = entry.sets.filter(s=>s.reps>0).map(s => `${s.weight}kg × ${s.reps}`).join(' | ');
        const item = document.createElement('div');
        item.style.cssText = 'padding: 6px; border-bottom: 1px solid var(--border-color); font-size: 0.85rem;';
        item.innerHTML = `<strong>${d.toLocaleDateString('pt-BR')}</strong>: <span class="mono">${setsStr}</span>`;
        historyListContainer.appendChild(item);
      });
    }

    document.getElementById('modal-exercise-detail').classList.remove('hidden');
  },

  // ------------------------------------------------------------------------
  // ROUTINES MANAGEMENT VIEW
  // ------------------------------------------------------------------------
  renderRoutinesManagement() {
    const routines = db.getRoutines();
    const container = document.getElementById('routines-management-list');
    container.innerHTML = '';

    routines.forEach(routine => {
      const card = document.createElement('div');
      card.className = 'section-card';
      card.style.display = 'flex';
      card.style.justifyContent = 'space-between';
      card.style.alignItems = 'center';

      card.innerHTML = `
        <div>
          <h3>${routine.name}</h3>
          <p class="meta-text">${routine.exerciseIds.length} exercícios cadastrados</p>
        </div>
        <div style="display: flex; gap: 6px;">
          <button class="btn btn-sm btn-outline" onclick="App.duplicateRoutine('${routine.id}')">Duplicar</button>
          <button class="btn btn-sm btn-outline" onclick="App.openEditRoutineModal('${routine.id}')">Editar</button>
          <button class="btn btn-sm btn-ghost-danger" onclick="App.deleteRoutine('${routine.id}')">🗑️</button>
        </div>
      `;

      container.appendChild(card);
    });
  },

  duplicateRoutine(id) {
    db.duplicateRoutine(id);
    this.renderRoutinesManagement();
  },

  deleteRoutine(id) {
    if (confirm('Tem certeza que deseja excluir esta rotina de treino?')) {
      db.deleteRoutine(id);
      this.renderRoutinesManagement();
    }
  },

  // ------------------------------------------------------------------------
  // EVENT BINDINGS
  // ------------------------------------------------------------------------
  bindEvents() {
    // Active session banner action buttons
    document.getElementById('btn-resume-active')?.addEventListener('click', () => {
      this.switchView('view-active-workout');
    });
    document.getElementById('btn-cancel-active')?.addEventListener('click', () => {
      if (confirm('Deseja descartar o treino em andamento? Todos os dados não finalizados serão perdidos.')) {
        db.clearActiveSession();
        this.activeSession = null;
        this.hideActiveWorkoutBanner();
        this.switchView('view-home');
      }
    });

    // Repeat last workout loads button
    document.getElementById('btn-apply-repeat-last')?.addEventListener('click', () => {
      this.applyRepeatLastWorkout();
    });

    // Finish workout
    document.getElementById('btn-finish-workout')?.addEventListener('click', () => {
      this.finishWorkout();
    });

    // Close summary modal
    document.getElementById('btn-close-summary')?.addEventListener('click', () => {
      document.getElementById('modal-workout-summary').classList.add('hidden');
      this.switchView('view-history');
    });

    // Modals close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.closest('.modal-overlay').classList.add('hidden');
      });
    });

    // Exercise Catalog search & chips
    document.getElementById('input-exercise-search')?.addEventListener('input', (e) => {
      this.renderExerciseCatalog('ALL', e.target.value);
    });

    document.querySelectorAll('#muscle-group-chips .chip-btn').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('#muscle-group-chips .chip-btn').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        this.renderExerciseCatalog(chip.getAttribute('data-group'), document.getElementById('input-exercise-search').value);
      });
    });

    // New exercise modal trigger & submit
    document.getElementById('btn-modal-new-exercise')?.addEventListener('click', () => {
      document.getElementById('form-exercise').reset();
      document.getElementById('form-ex-id').value = '';
      document.getElementById('modal-exercise-form').classList.remove('hidden');
    });

    document.getElementById('form-exercise')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const exObj = {
        id: document.getElementById('form-ex-id').value || null,
        name: document.getElementById('form-ex-name').value.trim(),
        muscleGroup: document.getElementById('form-ex-group').value,
        notes: document.getElementById('form-ex-observation').value.trim()
      };
      db.saveExercise(exObj);
      document.getElementById('modal-exercise-form').classList.add('hidden');
      this.renderExerciseCatalog();
    });

    // History tabs (List / Calendar)
    document.getElementById('btn-tab-list')?.addEventListener('click', () => {
      document.getElementById('btn-tab-list').classList.add('active');
      document.getElementById('btn-tab-calendar').classList.remove('active');
      document.getElementById('history-list-container').classList.remove('hidden');
      document.getElementById('history-calendar-container').classList.add('hidden');
    });

    document.getElementById('btn-tab-calendar')?.addEventListener('click', () => {
      document.getElementById('btn-tab-calendar').classList.add('active');
      document.getElementById('btn-tab-list').classList.remove('active');
      document.getElementById('history-calendar-container').classList.remove('hidden');
      document.getElementById('history-list-container').classList.add('hidden');
    });

    // Rest timer buttons
    document.getElementById('btn-timer-add30')?.addEventListener('click', () => restTimer.addTime(30));
    document.getElementById('btn-timer-stop')?.addEventListener('click', () => restTimer.stop());

    // Settings actions
    document.getElementById('select-unit')?.addEventListener('change', (e) => {
      const s = db.getSettings();
      s.weightUnit = e.target.value;
      db.saveSettings(s);
    });

    document.getElementById('select-theme')?.addEventListener('change', (e) => {
      const s = db.getSettings();
      s.theme = e.target.value;
      db.saveSettings(s);
      this.applySettings();
    });

    document.getElementById('select-default-rest')?.addEventListener('change', (e) => {
      const s = db.getSettings();
      s.restTimerDefault = parseInt(e.target.value);
      db.saveSettings(s);
    });

    document.getElementById('btn-export-backup-json')?.addEventListener('click', () => backupService.exportFullJSON());
    document.getElementById('btn-export-history-csv')?.addEventListener('click', () => backupService.exportHistoryCSV());
    
    document.getElementById('input-import-backup-json')?.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        backupService.importJSONFile(file, () => {
          alert('Backup importado com sucesso!');
          location.reload();
        }, (err) => alert('Erro ao importar backup: ' + err));
      }
    });

    document.getElementById('btn-reset-database')?.addEventListener('click', () => {
      if (confirm('ATENÇÃO: Deseja apagar todos os treinos e dados locais? Esta ação não pode ser desfeita.')) {
        db.resetAllData();
        location.reload();
      }
    });

    // AI Assistant actions
    document.getElementById('btn-ai-parse')?.addEventListener('click', () => {
      const text = document.getElementById('input-ai-text').value;
      const parsed = aiAssistant.parseText(text);
      const resultsArea = document.getElementById('ai-preview-results');
      const listContainer = document.getElementById('ai-parsed-exercises-list');

      if (!parsed) {
        alert('Não foi possível identificar exercícios no texto digitado. Digite frases como: "Supino reto 4x10 40kg, leg press 3x12 180kg"');
        return;
      }

      this.currentAIParsed = parsed;
      document.getElementById('ai-preview-title').textContent = parsed.title;
      resultsArea.classList.remove('hidden');
      listContainer.innerHTML = '';

      parsed.exercises.forEach(ex => {
        const card = document.createElement('div');
        card.className = 'section-card';
        const setsStr = ex.sets.map(s => `${s.weight > 0 ? s.weight + 'kg' : ''} × ${s.reps} reps`).join(', ');
        card.innerHTML = `
          <h3>${ex.exerciseName} <span class="ex-muscle-badge">${ex.muscleGroup}</span></h3>
          <p class="mono" style="margin-top: 4px; font-size: 0.9rem; color: var(--color-accent);">${ex.sets.length} séries: ${setsStr}</p>
        `;
        listContainer.appendChild(card);
      });
    });

    document.getElementById('btn-ai-start-now')?.addEventListener('click', () => {
      if (!this.currentAIParsed) return;
      const settings = db.getSettings();

      const exerciseEntries = this.currentAIParsed.exercises.map(ex => ({
        exerciseId: ex.exerciseId,
        exerciseName: ex.exerciseName,
        muscleGroup: ex.muscleGroup,
        sets: ex.sets.map((s, i) => ({
          setId: 'set-' + Date.now() + '-' + i,
          setNumber: i + 1,
          weight: s.weight,
          reps: s.reps,
          rir: 0,
          completed: false
        }))
      }));

      this.activeSession = {
        id: 'session-' + Date.now(),
        routineId: 'ai-session-' + Date.now(),
        routineName: this.currentAIParsed.title,
        startTime: new Date().toISOString(),
        status: 'in_progress',
        durationSeconds: 0,
        exerciseEntries: exerciseEntries
      };

      db.saveActiveSession(this.activeSession);
      this.showActiveWorkoutBanner();
      this.startWorkoutTimer();
      this.switchView('view-active-workout');
    });

    document.getElementById('btn-ai-save-routine')?.addEventListener('click', () => {
      if (!this.currentAIParsed) return;
      const exercises = db.getExercises();
      const exIds = this.currentAIParsed.exercises.map(ex => {
        let found = exercises.find(e => e.name.toLowerCase() === ex.exerciseName.toLowerCase());
        if (!found) {
          found = db.saveExercise({ name: ex.exerciseName, muscleGroup: ex.muscleGroup, notes: 'Criado via IA' });
        }
        return found.id;
      });

      db.saveRoutine({
        name: this.currentAIParsed.title,
        muscleFocus: 'Ficha rápida via IA',
        exerciseIds: exIds
      });

      alert('Rotina salva com sucesso!');
      this.switchView('view-routines');
    });

    document.getElementById('btn-ai-save-history')?.addEventListener('click', () => {
      if (!this.currentAIParsed) return;
      const session = {
        id: 'session-' + Date.now(),
        routineId: 'ai-direct',
        routineName: this.currentAIParsed.title,
        startTime: new Date().toISOString(),
        endTime: new Date().toISOString(),
        durationSeconds: 1800,
        status: 'completed',
        exerciseEntries: this.currentAIParsed.exercises.map(ex => ({
          exerciseId: ex.exerciseId,
          exerciseName: ex.exerciseName,
          muscleGroup: ex.muscleGroup,
          sets: ex.sets
        }))
      };

      db.saveWorkoutToHistory(session);
      alert('Treino registrado diretamente no Histórico!');
      this.switchView('view-history');
    });

    // PWA Install buttons handler
    const triggerPWAInstall = () => {
      if (this.deferredInstallPrompt) {
        this.deferredInstallPrompt.prompt();
        this.deferredInstallPrompt.userChoice.then((choiceResult) => {
          if (choiceResult.outcome === 'accepted') {
            console.log('Usuário aceitou a instalação do PWA');
          }
          this.deferredInstallPrompt = null;
        });
      } else {
        document.getElementById('modal-install-instructions')?.classList.remove('hidden');
      }
    };

    document.getElementById('btn-install-pwa')?.addEventListener('click', triggerPWAInstall);
    document.getElementById('btn-install-pwa-settings')?.addEventListener('click', triggerPWAInstall);

    // AI Routine Generator inside "Treinos" tab
    document.getElementById('btn-generate-routine-ai')?.addEventListener('click', () => {
      const routineName = document.getElementById('input-routine-ai-name').value.trim() || 'NOVO TREINO (IA)';
      const text = document.getElementById('input-routine-ai-text').value;

      const parsed = aiAssistant.parseText(text);
      if (!parsed || parsed.exercises.length === 0) {
        alert('Por favor, digite os exercícios e séries para gerar a ficha. Ex: "Supino reto 4x10, supino inclinado 3x8"');
        return;
      }

      const exercises = db.getExercises();
      const exIds = parsed.exercises.map(ex => {
        let found = exercises.find(e => e.name.toLowerCase() === ex.exerciseName.toLowerCase());
        if (!found) {
          found = db.saveExercise({ name: ex.exerciseName, muscleGroup: ex.muscleGroup, notes: 'Criado via IA' });
        }
        return found.id;
      });

      db.saveRoutine({
        name: routineName.toUpperCase(),
        muscleFocus: `${parsed.exercises.length} exercícios adicionados via IA`,
        exerciseIds: exIds
      });

      document.getElementById('input-routine-ai-name').value = '';
      document.getElementById('input-routine-ai-text').value = '';

      alert(`Ficha "${routineName.toUpperCase()}" criada com sucesso com ${exIds.length} exercícios!`);
      this.renderRoutinesManagement();
    });

    // PDF Uploader handlers
    const dropZone = document.getElementById('pdf-drop-zone');
    const fileInput = document.getElementById('pdf-file-input');

    document.getElementById('btn-trigger-pdf-select')?.addEventListener('click', () => fileInput.click());

    fileInput?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) this.processPDFFile(file);
    });
  },

  async processPDFFile(file) {
    const statusEl = document.getElementById('pdf-processing-status');
    const resultsArea = document.getElementById('pdf-preview-results');
    const detectedContainer = document.getElementById('pdf-detected-routines');

    statusEl.classList.remove('hidden');
    resultsArea.classList.add('hidden');

    try {
      const text = await pdfParser.extractTextFromPDF(file);
      const extractedRoutines = pdfParser.parseWorkoutText(text);

      statusEl.classList.add('hidden');
      resultsArea.classList.remove('hidden');
      detectedContainer.innerHTML = '';

      if (extractedRoutines.length === 0) {
        detectedContainer.innerHTML = '<p class="meta-text">Nenhum treino reconhecido automaticamente no arquivo PDF.</p>';
        return;
      }

      extractedRoutines.forEach((rot, idx) => {
        const card = document.createElement('div');
        card.className = 'section-card';
        let exListHtml = rot.exercises.map(e => `<li><strong>${e.name}</strong> (${e.setsInfo})</li>`).join('');

        card.innerHTML = `
          <h3>${rot.name}</h3>
          <ul style="margin: 8px 0 12px 20px; font-size: 0.88rem;">${exListHtml}</ul>
        `;
        detectedContainer.appendChild(card);
      });

      document.getElementById('btn-save-imported-routines').onclick = () => {
        const exercises = db.getExercises();
        extractedRoutines.forEach(rot => {
          const exIds = rot.exercises.map(ex => {
            let found = exercises.find(e => e.name.toLowerCase() === ex.name.toLowerCase());
            if (!found) {
              found = db.saveExercise({ name: ex.name, muscleGroup: 'Geral', notes: 'Importado de PDF' });
            }
            return found.id;
          });
          db.saveRoutine({
            name: rot.name,
            muscleFocus: 'Importado de PDF',
            exerciseIds: exIds
          });
        });
        alert('Treinos importados e salvos com sucesso!');
        this.switchView('view-routines');
      };

    } catch (err) {
      statusEl.classList.add('hidden');
      alert('Erro ao processar PDF: ' + err.message);
    }
  }
};
