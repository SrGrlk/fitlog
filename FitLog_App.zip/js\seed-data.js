/* ==========================================================================
   FITLOG - SEED DATA (INITIAL EXERCISE LIBRARY & UPPER/LOWER ROUTINES)
   ========================================================================== */

const INITIAL_EXERCISES = [
  // PEITO
  { id: 'ex-supino-reto-b', name: 'Supino Reto com Barra', muscleGroup: 'Peito', notes: 'Âncora de progressão. Série 1 = referência de PR. Registre sempre.' },
  { id: 'ex-supino-inc-h', name: 'Supino Inclinado c/ Halteres', muscleGroup: 'Peito', notes: '30–45°. Glenoumeral mais segura. Ângulo e implemento diferentes do U1.' },
  { id: 'ex-supino-reto-h', name: 'Supino Reto c/ Halteres', muscleGroup: 'Peito', notes: 'Mesmo plano do U1, mais ROM. Implemento diferente = variável neural alterada.' },
  { id: 'ex-crucifixo-inc-h', name: 'Crucifixo Inclinado c/ Halteres', muscleGroup: 'Peito', notes: 'Isolação peitoral. Ênfase no alongamento. RIR 0–1 ocasionalmente.' },
  { id: 'ex-peck-deck', name: 'Peck Deck / Fly Máquina', muscleGroup: 'Peito', notes: 'Adução com contração no pico. Incrementos menores vs halteres.' },
  { id: 'ex-crossover-cabo', name: 'Crossover no Cabo', muscleGroup: 'Peito', notes: 'Alta/média/baixa polia — variar a cada ciclo. Tensão constante do cabo.' },

  // COSTAS
  { id: 'ex-remada-curv-b', name: 'Remada Curvada com Barra', muscleGroup: 'Costas', notes: 'Antagonista imediato. Intercalar peito/costas reduz fadiga local.' },
  { id: 'ex-puxada-pronada', name: 'Puxada Frente — Pegada Pronada', muscleGroup: 'Costas', notes: 'Pull vertical. Straps recomendados — não limite pelo antebraço.' },
  { id: 'ex-remada-unilat-h', name: 'Remada Unilateral c/ Halter', muscleGroup: 'Costas', notes: 'Apoio no banco. Amplitude completa. Corrige assimetrias. Straps.' },
  { id: 'ex-puxada-neutra', name: 'Puxada Frente — Pegada Neutra', muscleGroup: 'Costas', notes: 'Triângulo ou barra V. Bíceps mais ativo. Straps precocemente.' },
  { id: 'ex-remada-cabo-baixo', name: 'Remada no Cabo Baixo (Low Row)', muscleGroup: 'Costas', notes: 'Tensão no alongamento. Peito no suporte. Straps recomendados.' },
  { id: 'ex-puxada-supinada', name: 'Puxada Supinada', muscleGroup: 'Costas', notes: 'Supinação ativa bíceps + latíssimo inferior. Terceiro padrão pull vertical.' },

  // OMBROS
  { id: 'ex-desenvolvimento-b', name: 'Desenvolvimento com Barra', muscleGroup: 'Ombros', notes: 'Press vertical pesado. Deltóide anterior + tríceps. Postura ereta.' },
  { id: 'ex-desenvolvimento-h', name: 'Desenvolvimento c/ Halteres', muscleGroup: 'Ombros', notes: 'Rotação natural do punho. Menos stress no manguito vs barra.' },
  { id: 'ex-press-arnold', name: 'Press Arnold / Press Máquina', muscleGroup: 'Ombros', notes: 'Arnold: rotação ativa cabeças anterior e medial. Máquina: estabilidade.' },
  { id: 'ex-elevacao-lat', name: 'Elevação Lateral com Halteres', muscleGroup: 'Ombros', notes: 'Manter controle no movimento. RIR 0–1.' },
  { id: 'ex-crucifixo-inv', name: 'Crucifixo Inverso na Polia', muscleGroup: 'Ombros', notes: 'Foco no deltoide posterior.' },

  // BÍCEPS
  { id: 'ex-rosca-direta-b', name: 'Rosca Direta com Barra', muscleGroup: 'Bíceps', notes: 'Cotovelos fixos. Supinação no topo. Bíceps frescos neste ponto.' },
  { id: 'ex-rosca-martelo-h', name: 'Rosca Martelo c/ Halteres', muscleGroup: 'Bíceps', notes: 'Pegada neutra. Braquiorradial e braquial. Padrão diferente do U1.' },
  { id: 'ex-rosca-scott-h', name: 'Rosca Scott c/ Halteres', muscleGroup: 'Bíceps', notes: 'Suporte elimina compensações. Ênfase na porção distal do bíceps.' },

  // TRÍCEPS
  { id: 'ex-triceps-testa-ez', name: 'Tríceps Testa com Barra EZ', muscleGroup: 'Tríceps', notes: 'Cotovelos apontados para cima. Pré-ativados pelos press anteriores.' },
  { id: 'ex-triceps-corda', name: 'Tríceps na Corda (Cabo)', muscleGroup: 'Tríceps', notes: 'Tensão constante. Separar pontas no final. Diferente da barra EZ do U1.' },
  { id: 'ex-triceps-frances-unilat', name: 'Tríceps Francês Unilateral', muscleGroup: 'Tríceps', notes: 'Cabeça longa em alongamento máximo. Amplitude total. Cotovelo para cima.' },

  // PERNAS (QUADRÍCEPS & POSTERIOR)
  { id: 'ex-hack-squat', name: 'Hack Squat', muscleGroup: 'Pernas', notes: 'Âncora. Costas no apoio. Pés médio-baixos. Carga axial reduzida vs agachamento.' },
  { id: 'ex-cadeira-extensora', name: 'Cadeira Extensora', muscleGroup: 'Pernas', notes: 'Isolação direta do quadríceps. Pico de contração. RIR 0–1 ocasionalmente.' },
  { id: 'ex-leg-press-45', name: 'Leg Press 45°', muscleGroup: 'Pernas', notes: 'Pés médios. Não trave joelhos no topo. Volume adicional de quadríceps.' },
  { id: 'ex-leg-press-altos', name: 'Leg Press 45° (pés altos)', muscleGroup: 'Pernas', notes: 'Pés altos = mais glúteo e ísquio. Mesmo equipamento do L1, ênfase diferente.' },
  { id: 'ex-stiff-h', name: 'Stiff c/ Halteres', muscleGroup: 'Pernas', notes: 'Âncora. ROM maior que barra. Straps obrigatórios. Neutro lombar todo o mov.' },
  { id: 'ex-cadeira-flexora', name: 'Cadeira Flexora', muscleGroup: 'Pernas', notes: 'Equilíbrio articular mesmo no dia de quad. Excêntrico controlado.' },
  { id: 'ex-terra-rdl-b', name: 'Terra Romeno (RDL) c/ Barra', muscleGroup: 'Pernas', notes: 'Âncora. Barra rente ao corpo. Straps obrigatórios. Carga superior ao halter L2.' },

  // PANTURRILHA
  { id: 'ex-panturrilha-em-pe', name: 'Panturrilha em Pé (Máquina)', muscleGroup: 'Panturrilha', notes: 'Joelho estendido = gastrocnêmio dominante. Pausa no alongamento.' },
  { id: 'ex-panturrilha-sentado', name: 'Panturrilha Sentado (Máquina)', muscleGroup: 'Panturrilha', notes: 'Joelho flexionado = sóleo dominante. Alterna com L1 para tríceps sural completo.' },
  { id: 'ex-panturrilha-pausa', name: 'Panturrilha em Pé + Pausa 2s', muscleGroup: 'Panturrilha', notes: 'Pausa de 2s no máximo alongamento. Range menor compensa a pausa adicional.' }
];

const INITIAL_ROUTINES = [
  {
    id: 'routine-upper-1',
    name: 'UPPER 1 — Força Primária (Barra)',
    muscleFocus: 'Press → Remada → Press → Puxada (Âncora: Supino Reto Barra)',
    exerciseIds: ['ex-supino-reto-b', 'ex-remada-curv-b', 'ex-desenvolvimento-b', 'ex-puxada-pronada', 'ex-crucifixo-inc-h', 'ex-rosca-direta-b', 'ex-triceps-testa-ez'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'routine-upper-2',
    name: 'UPPER 2 — Acúmulo (Halteres)',
    muscleFocus: 'Volume em Halteres (Âncora: Supino Inclinado Halteres)',
    exerciseIds: ['ex-supino-inc-h', 'ex-remada-unilat-h', 'ex-desenvolvimento-h', 'ex-puxada-neutra', 'ex-peck-deck', 'ex-rosca-martelo-h', 'ex-triceps-corda'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'routine-upper-3',
    name: 'UPPER 3 — Misto Força/Volume',
    muscleFocus: 'Misto Carga/Rom (Âncora: Supino Reto Halteres)',
    exerciseIds: ['ex-supino-reto-h', 'ex-remada-cabo-baixo', 'ex-press-arnold', 'ex-puxada-supinada', 'ex-crossover-cabo', 'ex-rosca-scott-h', 'ex-triceps-frances-unilat'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'routine-lower-1',
    name: 'LOWER 1 — Ênfase Quadríceps (Força)',
    muscleFocus: 'Joelho Dominante (Âncora: Hack Squat)',
    exerciseIds: ['ex-hack-squat', 'ex-cadeira-extensora', 'ex-leg-press-45', 'ex-cadeira-flexora', 'ex-panturrilha-em-pe'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'routine-lower-2',
    name: 'LOWER 2 — Ênfase Posterior (Volume)',
    muscleFocus: 'Quadril Dominante (Âncora: Stiff c/ Halteres)',
    exerciseIds: ['ex-stiff-h', 'ex-cadeira-flexora', 'ex-leg-press-altos', 'ex-cadeira-extensora', 'ex-panturrilha-sentado'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'routine-lower-3',
    name: 'LOWER 3 — Misto (RDL Barra)',
    muscleFocus: 'Misto / RDL Barra (Âncora: Terra Romeno RDL)',
    exerciseIds: ['ex-terra-rdl-b', 'ex-leg-press-45', 'ex-cadeira-extensora', 'ex-cadeira-flexora', 'ex-panturrilha-pausa'],
    createdAt: new Date().toISOString()
  }
];
